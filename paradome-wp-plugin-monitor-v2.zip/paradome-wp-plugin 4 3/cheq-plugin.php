<?php

/**
 * Paradome Real-Time Interception
 *
 * Plugin Name:       Paradome Real-Time Interception
 * Description:       Paradome Real-Time Interception protect your site from invalid traffic.
 * Version:           2.4.1
 * Requires at least: 5.2
 * Requires PHP:      5.4
 * Author:            Cheq.ai
 * Author URI:        https://cheq.ai
 * Text Domain:       cheq
 */

if (!defined('ABSPATH')) {
    die;
}
define('cheq_plugin_VERSION', '2.4.1');
define('cheq_plugin_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('cheq_plugin_PLUGIN_URL', plugin_dir_url(__FILE__));

const CHEQ_CAPTCHA_COOKIE_KEY = 'VALID_CAPTCHA';
const CHEQ_QUERY_KEY = "user_id";

/**
 * Provide settings fields
 *
 * @package cheq_plugin
 */
class WP_cheq_plugin
{
    /**
     * Plugin constructor.
     */
    public function __construct()
    {
        add_action('send_headers', array($this, 'cheq_server_validation'), -999);
        add_action('wp_enqueue_scripts', array($this, 'enqueue_custom_scripts'), -999);
        add_action('wp_ajax_validate_cheq_response',  array($this, 'check_with_cheq'), -999);
        add_action('wp_ajax_nopriv_validate_cheq_response',  array($this, 'check_with_cheq'), -999);
        add_action('admin_init', array($this, 'load_font_awesome'));
        add_action('admin_notices', array($this, 'invalid_secret_error'));
    }

    public function load_font_awesome()
    {
        wp_enqueue_style('fontawesome', 'https://use.fontawesome.com/releases/v5.8.1/css/all.css', '', '5.8.1');
    }

    public function invalid_secret_error()
    {
        if (get_option('cheq_invalid_secret')) {
?>
            <div class="error notice-error is-dismissible">
                <p>Paradome Real-Time Interception: Wrong Secret Key</p>
            </div>
        <?php
        }
    }

    public function create_server_log($validated, $action = "")
    {
        LogService::log(
            "Server",
            $action,
            Utils::getValueOrDefault($validated['output']->version),
            Utils::getValueOrDefault($validated['output']->isInvalid),
            Utils::getValueOrDefault($validated['output']->threatTypeCode),
            Utils::getValueOrDefault($validated['output']->requestId),
            Utils::getValueOrDefault($validated['output']->riskScore),
            Utils::getValueOrDefault($validated['output']->setCookie)
        );
    }

    public function rti_validate()
    {
        $rtiService = new RTI_Service();

        global $wp;

        $cheq_auth_key = get_option('cheq_auth_key', '');
        $current_page = home_url($wp->request);
        $cheq_account_id = get_option('cheq_account_id', '');
        if ($cheq_account_id && $cheq_auth_key) {
            $validated = $rtiService->validate_rti($cheq_auth_key, $current_page, 'page_load', $cheq_account_id);
            $invalid_captcha = UserCaptchaCodes::BLOCKED_USER;
            if (!$validated['is_valid'] || (isset($_GET[CHEQ_QUERY_KEY]) && ($_GET[CHEQ_QUERY_KEY] == $invalid_captcha || $_GET[CHEQ_QUERY_KEY] == "clearhtml"))) {
                if (get_option("cheq_action_field", '') == 'blockuser') {
                    $this->create_server_log($validated, "blockuser");
                    LogService::log("info", "blockuser", "", "", "", "", "", "", "", "Successfully blocked");
                    header('Status: 403 Forbidden', true, 403);
                    header('HTTP/1.0 403 Forbidden');
                    exit;
                } else if (get_option("cheq_action_field", '') == 'redirect') {
                    $this->create_server_log($validated, "redirect");
                    $redirect_target = get_option("cheq_redirect_url");

                    LogService::log("info", "redirect", "", "", "", "", "", "", "", "Successfully redirected to " . $redirect_target);
                    if (strpos($redirect_target, "?")) {
                        header('Location: ' . $redirect_target . '&user_id=' . $invalid_captcha);
                    } else {
                        header('Location: ' . $redirect_target . '?user_id=' . $invalid_captcha);
                    }
                    exit;
                }
                exit;
            } else if (($validated['is_valid'] && $validated['is_captcha'])) {
                if (!isset($_GET[CHEQ_QUERY_KEY]) || $_GET[CHEQ_QUERY_KEY] != UserCaptchaCodes::VALID_CAPTCHA) {
                    $this->create_server_log($validated, "captcha");
                    if ((!Utils::getCookieVariable(CHEQ_CAPTCHA_COOKIE_KEY)  && (!isset($_GET['user_id']) ||
                        (isset($_GET['user_id']) && $_GET['user_id'] != UserCaptchaCodes::HAS_CAPTCHA)))) {
                        define('DONOTCACHEPAGE', true);
                        $redirect_to = Utils::GetCaptchaRedirectUrl();
                        header('Location: ' . $redirect_to);
                        exit;
                    }
                }
            }
            $this->create_server_log($validated, "No action");
        } else {
            LogService::log("Server", "", "", "", "", "", "", ErrorCodes::NO_KEYS);
        }
    }


    public function cheq_captcha()
    {
        if (isset($_POST["h-captcha-response"]) && $_POST["h-captcha-response"]) {

            $url = 'https://hcaptcha.com/siteverify';
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'POST');

            $headers = array(
                "Content-Type: application/x-www-form-urlencoded",
            );
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

            $data = "response=" . $_POST["h-captcha-response"] . "&secret=" . get_option('cheq_captcha_secret');

            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

            $resp = curl_exec($curl);
            curl_close($curl);


            $result = json_decode($resp);
            if ($result->success) {
                $current_url = Utils::getServerVariable('REQUEST_URI');
                setcookie(CHEQ_CAPTCHA_COOKIE_KEY, '1', time() + 3600, COOKIEPATH, COOKIE_DOMAIN);
                $new_url = str_replace('user_id=' . UserCaptchaCodes::HAS_CAPTCHA, 'user_id=' . UserCaptchaCodes::VALID_CAPTCHA, $current_url);
                header('Location: ' . $new_url);
            } else {
                echo "Alert: Wrong SiteKey, Please contact website owner";
            }
        } else {
            $cssLink = plugins_url('/includes/assets/css/captcha.css', __FILE__);
            define('DONOTCACHEPAGE', true);
        ?>
            <meta http-equiv="Pragma" content="no-cache">
            <form method="POST">
                <h2><?php _e('Before you proceed, please complete the captcha below', 'cheq-plugin') ?></h2>
                <div class="h-captcha" data-sitekey="<?= get_option('cheq_captcha_api_key') ?>"></div>
                <button type="submit">Submit</button>
            </form>
            <script src="https://js.hcaptcha.com/1/api.js" async defer></script>
            <link rel="stylesheet" href="<?= $cssLink ?>" />
<?php
        }
    }

    public function cheq_server_validation()
    {
        $invalid_user_id = array(UserCaptchaCodes::BLOCKED_USER, "clearhtml");
        $redirect_target = get_option("cheq_redirect_url");
        $redirect_same_host = Utils::redirect_same_host($redirect_target);
        if (isset($_GET[CHEQ_QUERY_KEY]) && in_array($_GET[CHEQ_QUERY_KEY], $invalid_user_id)) {
            if (get_option("cheq_action_field", '') == 'blockuser') {
                LogService::log("info", "block user", "", "", "", "", "", "", "", "Successfully blocked");
                header('Status: 403 Forbidden', true, 403);
                header('HTTP/1.0 403 Forbidden');
                exit;
            } else if (get_option("cheq_action_field", '') == 'redirect' && !$redirect_same_host) {
                LogService::log("info", "redirect", "", "", "", "", "", "", "", "Successfully redirected to " . $redirect_target);
                header('Location: ' . $redirect_target . strpos($redirect_target, "?") ? '&' : '?' . 'user_id=' . UserCaptchaCodes::BLOCKED_USER);
                exit;
            }
        } else if (isset($_GET[CHEQ_QUERY_KEY]) && $_GET[CHEQ_QUERY_KEY] == UserCaptchaCodes::HAS_CAPTCHA) {
            Logservice::log("info", "captcha", "", "", "", "", "", "", "", "Successfully served captcha");
            $this->cheq_captcha();
            exit;
        } else {
            $this->rti_validate();
        }
    }

    // Validate request on Ajax
    public function check_with_cheq()
    {
        $rtiService = new RTI_Service();
        return $rtiService->validateRTIClient();
    }

    public function enqueue_custom_scripts()
    {
        wp_enqueue_script('cheqFrontEnd', plugin_dir_url(__FILE__) . 'includes/assets/js/front-end.js', array('jquery'), '1.2');
        wp_localize_script(
            'cheqFrontEnd',
            'ajax_obj',
            array(
                'nonce'         => wp_create_nonce('ajax-nonce'),
                'ajax_url'      => admin_url('admin-ajax.php'),
                'ajax_action'   => 'validate_cheq_response',
            )
        );
    }

    /**
     * Init Cheq Plugin.
     */
    public function init_cheq_field_setting()
    {
        // Add new admin menu options page for cheq Setting.
        add_action('admin_menu', array($this, 'create_cheq_plugin_options_page'));
        // Register Cheq Plugin settings.
        add_action('admin_init', array($this, 'register_cheq_fields_settings'));
        add_action('admin_init', array($this, 'cheq_admin_init'), 99);
    }

    /**
     * Admin init action with lowest execution priority
     */
    public function cheq_admin_init()
    {
        // Admin Scripts.
        add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
    }

    /**
     * Create the Cheq Plugin options page
     */
    public function create_cheq_plugin_options_page()
    {
        $options_form = new Plugin_Options_Form();
        add_menu_page(
            'Cheq Plugin',
            'Cheq Plugin',
            'manage_options',
            'cheq-plugin-options',
            array($options_form, 'cheq_plugin_options_page_html'),
            'dashicons-menu',
            150
        );
    }

    /*
     * Register AP Settings settings
     */
    public function register_cheq_fields_settings()
    {
        $options_form = new Plugin_Options_Form();

        add_settings_section(
            'cheq_fields_settings_section',
            __('General options', 'cheq-plugin'),
            '',
            'cheq-fields-settings-group'
        );
        add_settings_field(
            'cheq_plugins_auth_key',
            __('Authentication Key', 'cheq-plugin'),
            array($options_form, 'cheq_plugins_auth_key_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_plugins_account_id',
            __('Account ID', 'cheq-plugin'),
            array($options_form, 'cheq_plugins_account_id_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_plugins_secret_key',
            __('Secret Key', 'cheq-plugin'),
            array($options_form, 'cheq_plugins_secret_key_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_captcha_api_key',
            __('Action', 'cheq-plugin'),
            array($options_form, 'cheq_plugins_action_field_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_data_location_field',
            __('Location', 'cheq-plugin'),
            array($options_form, 'cheq_plugins_location_data_field_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_suspicious_action_field',
            __('For Suspicious Requests', 'cheq-plugin'),
            array($options_form, 'cheq_suspicious_action_field_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_captcha_api_key_field',
            __('hCaptcha SiteKey', 'cheq-plugin'),
            array($options_form, 'cheq_plugins_hcaptcha_site_key_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
        add_settings_field(
            'cheq_captcha_secret_field',
            __('hCaptcha SecretKey', 'cheq-plugin'),
            array($options_form, 'cheq_plugins_hcaptcha_secret_key_render'),
            'cheq-fields-settings-group',
            'cheq_fields_settings_section'
        );
    }


    /**
     * Load Admin scripts
     */
    public function admin_enqueue_scripts($hook)
    {
        wp_enqueue_script(
            'cheq-setting-admin',
            plugins_url('/includes/assets/js/cheq-setting-admin.js', __FILE__),
            array('jquery'),
            cheq_plugin_VERSION
        );
        wp_enqueue_style('cheq-setting-style', plugins_url('/includes/assets/css/cheq-setting-style.css', __FILE__), cheq_plugin_VERSION);
    }
}

set_error_handler(function ($errno, $errstr, $errfile, $errline) {
    if (strpos($errfile, cheq_plugin_PLUGIN_PATH) !== false) {
        $error_msg = "errorno:" . $errno . ",errstr:" . $errstr . ",errfile:" . $errfile . ",errline:" . $errline;
        LogService::log("Plugin", "", "", "", "", "", "", "", ErrorCodes::ERROR, $error_msg);
    }
});

$cheq_plugins = new WP_cheq_plugin();
$cheq_plugins->init_cheq_field_setting();
require_once cheq_plugin_PLUGIN_PATH . 'classes/enums.php';
require_once cheq_plugin_PLUGIN_PATH . 'classes/logService.php';
require_once cheq_plugin_PLUGIN_PATH . 'classes/rtiServer.php';
require_once cheq_plugin_PLUGIN_PATH . '/classes/utils.php';
require_once cheq_plugin_PLUGIN_PATH . '/src/components/settingsForm.php';
