function onCheqResponse(encryptedMessage) {
  if (window.location.href.includes("user_id=")) {
    let get_parameter = findGetParameter("user_id")
    editAllInternalLinks(get_parameter)
  }
  console.log(encryptedMessage)
  let encodedMessage = encryptedMessage.replaceAll("+", "-----")
  let request = new XMLHttpRequest()
  request.open("POST", ajax_obj.ajax_url, true)
  request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
  request.send(
    "action=" +
      ajax_obj.ajax_action +
      "&nonce=" +
      ajax_obj.nonce +
      "&cheq_hash=" +
      encodedMessage
  )
  request.onreadystatechange = function () {
    if (request.readyState === 4) {
      if (request.status === 200) {
        console.log(request.responseText)
        const responseMessage = JSON.parse(request.responseText).message
        const res = responseMessage.res
        if (res) {
          if (res === "ch") document.querySelector("html").innerHTML = ""
          else window.location.href = res
        }
      } else {
        console.log("Error: " + request.status)
      }
    }
  }
}

function findGetParameter(parameter) {
  let url = window.location.href

  if (url.includes("?" + parameter) || !url.includes("?" + parameter)) {
  } else {
    return
  }

  let parameter_index = url.indexOf(parameter + "=") + parameter.length + 1
  let next_parameter_index = url.indexOf("&", parameter_index)
  if (next_parameter_index > 0) {
    return url.substring(parameter_index, next_parameter_index)
  } else {
    return url.substring(parameter_index)
  }
}

function editAllInternalLinks(value) {
  domain = window.location.hostname
  links = document.getElementsByTagName("a")
  for (let i = 0; i < links.length; i++) {
    let link_url = links[i].getAttribute("href")
    if (link_url != null && link_url.includes(domain)) {
      const url = updateQueryStringParameter(link_url, "user_id", value)
      links[i].setAttribute("href", url)
    }
  }
}
function updateQueryStringParameter(uri, key, value) {
  var re = new RegExp("([?&])" + key + "=.*?(&|$)", "i")
  var separator = uri.indexOf("?") !== -1 ? "&" : "?"
  if (uri.match(re)) {
    return uri.replace(re, "$1" + key + "=" + value + "$2")
  } else {
    return uri + separator + key + "=" + value
  }
}

function getCookie(name) {
  const value = `; ${document.cookie}`
  const parts = value.split(`; ${name}=`)
  if (parts.length === 2) return parts.pop().split(";").shift()
}
