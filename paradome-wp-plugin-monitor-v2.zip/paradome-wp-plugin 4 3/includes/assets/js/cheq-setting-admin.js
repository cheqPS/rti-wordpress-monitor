jQuery(document).ready(function ($) {
  const cheqCaptchaSiteKeyElement = $("#cheq_hcaptcha_site_key")
  const cheqCaptchaSecretKeyElement = $("#cheq_hcaptcha_secret_key")

  function initCheq() {
    handleCaptchaFields()
  }

  // validate action radio and input field
  $("#cheq_action_field_blockuser, #cheq_action_field_cf7key").click(
    function () {
      $("#cheq_redirect_url").prop("disabled", true)
      $("input#cheq_redirect_url.hide").hide()
    }
  )
  $("#cheq_action_field_redirect_label").click(function () {
    $("#cheq_redirect_url").removeAttr("disabled")
    $("input#cheq_redirect_url.hide").show()
  })

  $("#cheq_suspicious_action_field").click(function () {
    handleCaptchaFields()
  })

  $("#show_password").click(function () {
    $(this).hide()
    $("#hide_password").show()
    $("input#cheq_secret_key").attr("type", "text")
  })
  $("#hide_password").click(function () {
    $(this).hide()
    $("#show_password").show()
    $("input#cheq_secret_key").attr("type", "password")
  })
  function handleCaptchaFields() {
    if ($("#cheq_suspicious_action_field").is(":checked")) {
      cheqCaptchaSiteKeyElement.closest("tr").show()
      cheqCaptchaSecretKeyElement.closest("tr").show()
    } else {
      cheqCaptchaSiteKeyElement.closest("tr").hide()
      cheqCaptchaSecretKeyElement.closest("tr").hide()
    }
  }

  initCheq()
})
