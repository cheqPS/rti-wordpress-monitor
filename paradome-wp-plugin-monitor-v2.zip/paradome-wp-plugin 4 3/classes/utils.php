<?php

class Utils
{

    //todo: use this to handle exceptions
    public static function getServerVariable($key)
    {
        return isset($_SERVER[$key]) ? $_SERVER[$key] : '';
    }

    public static function getCookieVariable($key)
    {
        return isset($_COOKIE[$key]) ? $_COOKIE[$key] : '';
    }

    public static function get_the_user_ip()
    {
        if (!empty(Utils::getServerVariable('HTTP_CLIENT_IP'))) {
            //check ip from share internet
            $ip = Utils::getServerVariable('HTTP_CLIENT_IP');
        } elseif (!empty(Utils::getServerVariable('HTTP_X_FORWARDED_FOR'))) {
            //to check ip is pass from proxy
            $ip = Utils::getServerVariable('HTTP_X_FORWARDED_FOR');
        } else {
            $ip = Utils::getServerVariable('REMOTE_ADDR');
        }
        return explode(',', apply_filters('wpb_get_ip', $ip))[0];
    }
    public static function GetCaptchaRedirectUrl()
    {
        $protocol = !empty(Utils::getServerVariable('HTTPS')) && Utils::getServerVariable('HTTPS') !== 'off' ? 'https://' : 'http://';
        $partialUrl = Utils::getServerVariable('HTTP_HOST') . Utils::getServerVariable('REQUEST_URI');
        $full_url = $protocol . $partialUrl;

        $redirect_to = Utils::removeqsvar($full_url, 'user_id');
        $captcha_path = 'user_id=' . UserCaptchaCodes::HAS_CAPTCHA;
        if (strpos($redirect_to, '?') !== false) {
            $redirect_to .= '&' . $captcha_path;
        } else {
            $redirect_to .= '?' . $captcha_path;
        }
        $res = $redirect_to;
        return $res;
    }
    public static function removeqsvar($url, $varname)
    {
        return preg_replace('/([?&])' . $varname . '=[^&]+(&|$)/', '$1', $url);
    }
    public static function getValueOrDefault($value)
    {
        return isset($value) ? $value : '';
    }

    public static function append_query_string($key, $value, $url)
    {
        $res = "";
        if (strpos($url, "?") !== false) {
            $res = $url . "&" . $key . "=" . $value;
        } else {
            $res = $url . "?" . $key . "=" . $value;
        }
        return $res;
    }
    public static function redirect_same_host($redirect_url)
    {
        $res = false;
        if (!$redirect_url) {
            $site_url = get_site_url();
            $site_host  = parse_url($site_url)["host"];
            $redirect_url_host = parse_url($redirect_url)["host"];
            $res = $site_host == $redirect_url_host;
        }

        return $res;
    }
}
