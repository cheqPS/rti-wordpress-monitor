<?php
require_once cheq_plugin_PLUGIN_PATH . 'classes/enums.php';

class LogService
{
    public static function log($logger, $required_action="", $version="", $isInvalid="", $threatType="", $request_id="", $risk_score = null, $set_cookie = null, $errorCode = 0, $msg = "")
    {
        $tag_hash =  get_option('cheq_account_id');
        $cheq_auth_key = get_option('cheq_auth_key', '');

        if ($tag_hash || $cheq_auth_key) {
            $log_message = "[" . date("d/m/Y-H:i:s") . "] - " . $logger . "\n";
            $log_message .= $required_action . "\n";
            $log_message .= "\tVersion: " . $version . "\n";
            $log_message .= "\tisInvalid: " . $isInvalid . "\n";
            $log_message .= "\tThreatType: " . $threatType . "\n";
            $log_message .= "\tRequestID: " . $request_id . "\n";
            if (!is_null($risk_score)) {
                $log_message .= "\tRiskScore: " . $risk_score . "\n";
            }
            if (!is_null($set_cookie)) {
                $log_message .= "\tSetCookie: " . $set_cookie . "\n";
            }
            $site_url = get_site_url();
            $log_message .= "\tSite Url: " . $site_url . "\n";
            $log_message .= "\tErrorCode: " . $errorCode . "\n";
            $log_message .= "\PluginVersion: " . cheq_plugin_VERSION . "\n";
            if ($msg) {
                $log_message .= "\logMessage: " . $msg . "\n";
            }

            LogService::remote_log("info", $tag_hash, $cheq_auth_key, $log_message, "Paradome", $required_action, $site_url, $errorCode);
            $log_message .= "------------------------------------------------------------------------------\n";
        }
    }

    private static function remote_log($level, $tag_hash, $api_key, $message, $application, $action, $site_url, $errorCode)
    {

        $data = new stdClass();
        $data->level        = $level;
        $data->tagHash      = $tag_hash;
        $data->apiKey       = $api_key;
        $data->message      = $message;
        $data->application  = $application;
        $data->action       = $action;
        $data->site_url     = $site_url;
        $data->errorCode    = $errorCode;

        $dataStr = json_encode($data);
        $dataLocationOption = get_option('cheq_data_location_field', '');
        $rtiUrl = $dataLocationOption == Regions::EUROPE? URLS::RTI_LOGGER_EUROPE: URLS::RTI_LOGGER_US;
        wp_remote_post($rtiUrl, array(
            'method' => 'POST',
            'timeout' => 0.5,
            'redirection' => 5,
            'blocking' => false,
            'headers' => array(
                'Content-Type' => 'application/json'
            ),
            'body' => $dataStr,
        ));
    }
}
