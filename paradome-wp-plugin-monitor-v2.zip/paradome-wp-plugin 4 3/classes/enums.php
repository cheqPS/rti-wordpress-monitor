<?php

abstract class ErrorCodes
{
    const NO_KEYS = 2007;
    const AUTH_ERROR = 2008;
    const RTI_SERVER_AUTH_ERROR = 2009;
    const RTI_SERVER_NO_RESPONSE = 2011;
    const RTI_SERVER_MISSING_THREAT_TYPE = 2012;
    const INCORRECT_SECRET_KEY = 2013;
    const RTI_SERVER_INCORRECT_COOKIE = 2014;
    const RTI_SERVER_EMPTY_RESPONSE_FORMAT = 2015;
    const RTI_SERVER_INVALID_RESPONSE_FORMAT = 2016;
    const RTI_SERVER_MISSING_COOKIE = 2017;
    const RTI_SERVER_MISSING_DATA_LOCATION = 2018;

    const ERROR = 2000;
}

abstract class AllowedCodes
{
    const VALID = 0;
    const CLICK_HIJACKING = 17;
    const GOOD_BOT = 19;
}

abstract class SuspiciousCodes
{
    const MONITOR = 40;
/*  const FREQUENCY_CAPPING = 4;
    const ABNORMAL_RATE_LIMIT = 5;
    const DATA_CENTER = 13;
    const VPN = 14;
    const PROXY = 15;
    const CRAWLERS = 20;*/
}

abstract class UserCaptchaCodes
{
    const VALID_CAPTCHA = "ACCF8B33";
    const HAS_CAPTCHA = "4F9FF23A";
    const BLOCKED_USER = "D671A39D";
}

//todo: fix links
abstract class URLS
{
    const CHEQZONE_US = 'https://ob.cheqzone.com';
    const CHEQZONE_EUROPE = 'https://euseek.hideousplay.com/sxp';
    const RTI_SERVER_US = 'https://obs.cheqzone.com/v1/realtime-interception';
    const RTI_SERVER_EUROPE = 'https://rti-eu-west-1.cheqzone.com/v1/realtime-interception';
    const RTI_LOGGER_US = 'https://rtilogger.production.cheq-platform.com/';
    const RTI_LOGGER_EUROPE = 'https://rtilogger.production.cheq-platform.com/'; //todo: use correct url
}
abstract class Regions
{
    const US = 1;
    const EUROPE = 2;
}
