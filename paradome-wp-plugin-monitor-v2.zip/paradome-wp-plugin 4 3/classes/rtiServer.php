<?php
require_once cheq_plugin_PLUGIN_PATH . 'classes/enums.php';

const ALLOWED_CODES = [
    AllowedCodes::VALID,
    AllowedCodes::CLICK_HIJACKING,
    AllowedCodes::GOOD_BOT
];

const SUSPICIOUS_CODES = [
    SuspiciousCodes::MONITOR
/*  SuspiciousCodes::FREQUENCY_CAPPING,
    SuspiciousCodes::ABNORMAL_RATE_LIMIT,
    SuspiciousCodes::DATA_CENTER,
    SuspiciousCodes::VPN,
    SuspiciousCodes::PROXY,
    SuspiciousCodes::CRAWLERS*/
];


class RTI_Service
{
    //todo: get rid of magic numbers
    public function validate_rti($api_key, $request_url, $event_type, $tag_hash)
    {
        $domain = str_replace('http://', '', get_site_url());
        $domain = str_replace('https://', '', $domain);
        $client_ip = Utils::get_the_user_ip();

        $request_params = [
            'ApiKey' => $api_key,
            'ClientIP' => $client_ip,
            'RequestURL' => $request_url,
            'ResourceType' => 'text/html',
            'Method' => 'GET',
            'Host' => strtok($domain, '/'),
            'UserAgent' => Utils::getServerVariable('HTTP_USER_AGENT'),
            'Accept' => Utils::getServerVariable('HTTP_ACCEPT'),
            'AcceptLanguage' => Utils::getServerVariable('HTTP_ACCEPT_LANGUAGE'),
            'AcceptEncoding' => Utils::getServerVariable('HTTP_ACCEPT_ENCODING'),
            'HeaderNames' => 'Host,User-Agent,Accept,Accept-Langauge,Accept-Encoding',
            'EventType' => $event_type,
            'TagHash' => $tag_hash,
        ];

        if ($event_type == 'page_load') {
            $request_params['HeaderNames'] = 'Host,User-Agent,Accept,Accept-Langauge,Accept-Encoding,Cookie';
            $request_params['CheqCookie'] = Utils::getCookieVariable('_cheq_rti');
            $request_params['Referer'] = Utils::getServerVariable('HTTP_REFERER');
            $request_params['Connection'] = Utils::getServerVariable('HTTP_CONNECTION');
        }

        $query_string = '';
        $counter = 0;
        foreach ($request_params as $key => $value) {
            if ($counter > 0) {
                $query_string .= "&";
            }
            $query_string .= $key . '=' . $value;
            $counter++;
        }

        $location = get_option('cheq_data_location_field');
        $curl = curl_init();
        $url = $location == Regions::EUROPE ? URLS::RTI_SERVER_EUROPE : URLS::RTI_SERVER_US;

        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $query_string,
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded'],
        ]);

        $response = curl_exec($curl);


        $httpcode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

        if ($response === false) {
            $error = curl_error($curl);
            $this->send_error($request_params, $error);
        }
        curl_close($curl);

        if ($event_type == 'token_validation') {
            if ($httpcode == 200) {
                return true;
            }

            return false;
        } else if ($event_type == 'page_load') {

            $output = json_decode($response);
            if (is_object($output)) {
                if (!isset($output->setCookie)) {
                    LogService::log("Server", "", "", "", "", "", "", "", ErrorCodes::RTI_SERVER_MISSING_COOKIE);
                } else {
                    $cookie_values = explode(';', $output->setCookie);

                    $cookie_name_value = explode('=', $cookie_values[0], 2);
                    if (isset($cookie_name_value) && isset($cookie_values) && count($cookie_name_value) > 1 && count($cookie_values) > 2) {
                        setcookie($cookie_name_value[0], $cookie_name_value[1], strtotime(explode('=', $cookie_values[1])[1]), explode('=', $cookie_values[3])[1]);
                    } else {
                        LogService::log("Server", "", "", "", "", "", "", "", ErrorCodes::RTI_SERVER_INCORRECT_COOKIE);
                    }

                    if (!isset($output->version) || !is_numeric($output->version)) {
                        update_option('cheq_invalid_secret', true);
                        LogService::log("Server", "", "", "", "", "", "", "", ErrorCodes::RTI_SERVER_AUTH_ERROR);
                    } else {
                        update_option('cheq_invalid_secret', false);
                    }

                    if (!isset($output->threatTypeCode)) {
                        LogService::log("Server", "", "", "", "", "", "", "", ErrorCodes::RTI_SERVER_MISSING_THREAT_TYPE);
                    } else if (in_array($output->threatTypeCode, ALLOWED_CODES)) {
                        return array(
                            "is_valid"      => true,
                            "is_captcha"    => false,
                            "output"        => $output
                        );
                    } else if (in_array($output->threatTypeCode, SUSPICIOUS_CODES)) {
                        if (get_option('cheq_suspicious_action')) {
                            return array(
                                "is_valid"      => true,
                                "is_captcha"    => true,
                                "output"        => $output
                            );
                        } else {
                            return array(
                                "is_valid"      => true,
                                "is_captcha"    => false,
                                "output"        => $output
                            );
                        }
                    }/* else if ($output->isInvalid) {
                        return array(
                            "is_valid"      => false,
                            "is_captcha"    => false,
                            "output"        => $output
                        );
                    }*/
                }
            } else {
                if (!isset($output)) {
                    LogService::log("Server", "", "", "", "", "", "", "", ErrorCodes::RTI_SERVER_EMPTY_RESPONSE_FORMAT);
                } elseif (!is_object($output)) {
                    LogService::log("Server", "", "", "", "", "", "", "", ErrorCodes::RTI_SERVER_INVALID_RESPONSE_FORMAT);
                }
            }
        }
        return array(
            "is_valid"      => true,
            "is_captcha"    => false,
            "output"        => $output
        );
    }
    public function validateRTIClient()
    {


        // Validate nonce
        if (!wp_verify_nonce($_POST["nonce"], "ajax-nonce")) {
            echo json_encode(array(
                "status"    => 400,
                "message"   => "Request could not be validated"
            ));
            exit;
        }

        // Validate cheq hash
        if (!isset($_POST['cheq_hash']) || empty($_POST['cheq_hash'])) {
            echo json_encode(array(
                "status"    => 400,
                "error"     => "No hash",
            ));
            exit;
        }

        $message = str_replace("-----", "+", $_POST['cheq_hash']);

        $ciphering = 'AES-192-CTR';
        $options = 0;
        $iv = substr($message, 0, 16);
        $encrypted_message = substr($message, 16);
        $secret_key = get_option('cheq_secret_key', '');

        // abe7fbd35ec78758cb936506
        $decrypted_message = openssl_decrypt($encrypted_message, $ciphering, $secret_key, $options, $iv);

        $output = explode(":", $decrypted_message);

        if (count($output) > 1 && !is_numeric($output[0])) {
            update_option('cheq_invalid_secret', true);
        } else {
            update_option('cheq_invalid_secret', false);
        }

        if (count($output) < 4) {
            update_option('cheq_invalid_secret', true);
            LogService::log("Front", "", "", "", "", "", "", ErrorCodes::INCORRECT_SECRET_KEY);
            exit;
        } else {
            update_option('cheq_invalid_secret', false);
        }

        $required_action = "";


        // Do no block threat types 19 and 20 even if they return invalid
        if (intval($output[2]) == AllowedCodes::GOOD_BOT) {
            // If the threat type is in the suspicious threat type codes, and the user chose to display captcha
            if (in_array(intval($output[2]), SUSPICIOUS_CODES) && get_option('cheq_suspicious_action')) {
                wp_cache_flush();
                if ((!isset($_GET[CHEQ_QUERY_KEY]) || $_GET[CHEQ_QUERY_KEY] != UserCaptchaCodes::VALID_CAPTCHA)
                    && !Utils::getCookieVariable(CHEQ_CAPTCHA_COOKIE_KEY)
                )
                    $required_action = "captcha";
                // If the threat type is either 7 or 16, empty the HTML element using JavaScript: replace with
            } else if (intval($output[2]) == 40 || intval($output[2]) == 40) {
                wp_cache_flush();
                $required_action = "clearhtml";
            }
        }
        // If request is invalid
        else if (intval($output[1]) && in_array(intval($output[2]), array(40))) {
            if ($required_action == "") {
                if (get_option("cheq_action_field", '') == "blockuser") {
                    wp_cache_flush();
                    $required_action = "blockuser";
                } else if (get_option("cheq_action_field", '') == "redirect") {
                    wp_cache_flush();
                    $required_action = "redirect";
                }
            }
        }


        logService::log(
            "Front",
            $required_action ? $required_action : 'No action',
            $output[0],
            $output[1],
            $output[2],
            $output[3]
        );
        $required_action = $this->get_redirect_url($required_action, get_option('cheq_redirect_url', ''));
        // Send response to Ajax
        echo json_encode(array(
            "status"    => 200,
            "message"   => array(
                "res"        => $required_action
            ),
        ));
        exit;
    }

    private function get_redirect_url($required_action, $redirect_url)
    {
        $url = Utils::getServerVariable('HTTP_REFERER');
        $cookie = Utils::getCookieVariable(CHEQ_CAPTCHA_COOKIE_KEY);

        $res = "";
        switch ($required_action) {
            case "captcha":
                if (!$cookie)
                    $res = Utils::append_query_string(CHEQ_QUERY_KEY, UserCaptchaCodes::HAS_CAPTCHA, $url);
                break;
            case "blockuser":
                $res = Utils::append_query_string(CHEQ_QUERY_KEY, UserCaptchaCodes::BLOCKED_USER, $url);
                break;
            case "redirect":
                $res = $redirect_url;
                break;
            case "clearhtml":
                $res = "ch";
                break;
        }
        return $res;
    }

    private function send_error($request_params, $error)
    {
        $request = json_encode($request_params);
        $msg = "{\"Request\":{$request} , \"Error\":\"{$error}\"}";
        LogService::log("Plugin", "", "", "", "", "", "", "", ErrorCodes::ERROR, $msg);
    }
}
